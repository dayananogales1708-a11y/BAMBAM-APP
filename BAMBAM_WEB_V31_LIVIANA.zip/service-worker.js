const CACHE='bambam-v31-shell';
const CORE=['./','./index.html','./manifest.webmanifest','./iconos/bambam-perfil-blanco.png','./previews/carton_1.webp','./previews/carton_2.webp','./previews/carton_3.webp'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('bambam-v')&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET'||new URL(req.url).origin!==location.origin)return;
 const url=new URL(req.url);
 if(url.pathname.includes('/previews/')||url.pathname.includes('/iconos/')){
   event.respondWith(caches.match(req).then(async cached=>{
     if(cached)return cached;
     const response=await fetch(req);
     if(response.ok){const copy=response.clone();event.waitUntil(caches.open(CACHE).then(cache=>cache.put(req,copy)));}
     return response;
   }));
 }else if(req.mode==='navigate'){
   event.respondWith(fetch(req).catch(()=>caches.match('./index.html')));
 }
});
