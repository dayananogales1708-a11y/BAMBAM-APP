package bo.bambam.app;

import android.app.Activity;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The Android PDF engine draws the original bundled PDF page off the UI thread.
 * It avoids repeatedly loading 1000-page documents into pdf.js on every tap.
 * One worker keeps PdfRenderer single-threaded; a small preview cache makes
 * sequential lists responsive. The full PNG is saved straight to MediaStore.
 */
public final class NativeCards {
    private final Activity activity;
    private final WebView webView;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final PdfRenderer[] renderers = new PdfRenderer[3];
    private final ParcelFileDescriptor[] descriptors = new ParcelFileDescriptor[3];
    private final Map<Integer, byte[]> thumbnails = new LinkedHashMap<Integer, byte[]>(16, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Integer, byte[]> eldest) {
            return size() > 12;
        }
    };
    private final Map<Integer, byte[]> readyPNG = new LinkedHashMap<Integer, byte[]>(4, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Integer, byte[]> eldest) {
            return size() > 3;
        }
    };
    private volatile boolean closed = false;

    NativeCards(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    @JavascriptInterface public void preview(int number, int requestId) {
        io.execute(() -> {
            try {
                validate(number);
                byte[] jpg = thumbnail(number);
                String dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(jpg, Base64.NO_WRAP);
                respond("bambamNativePreview", requestId, true, dataUrl);
            } catch (Exception e) {
                respond("bambamNativePreview", requestId, false, friendly(e));
            }
        });
    }

    @JavascriptInterface public void prefetch(int number) {
        if (number < 1 || number > 3000) return;
        io.execute(() -> {
            try { thumbnail(number); } catch (Exception ignored) { }
        });
    }

    /** Prepare the current high-resolution PNG after its preview loads,
     * so the actual Descargar tap normally only writes cached bytes. */
    @JavascriptInterface public void warmDownload(int number) {
        if (number < 1 || number > 3000) return;
        io.execute(() -> {
            try { preparedPNG(number); } catch (Exception ignored) { }
        });
    }

    @JavascriptInterface public void saveCard(int number, int requestId) {
        io.execute(() -> {
            Uri uri = null;
            try {
                validate(number);
                // More pixels than the prototype's 1696-wide PNG, preserving
                // all vector numbers and the original banner composition.
                byte[] ready = preparedPNG(number);
                ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, "BAMBAM_carton_" + number + ".png");
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH,
                            Environment.DIRECTORY_PICTURES + "/BAMBAM");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    uri = activity.getContentResolver().insert(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IllegalStateException("No se pudo abrir la galería");
                    try (OutputStream output = activity.getContentResolver().openOutputStream(uri)) {
                        if (output == null)
                            throw new IllegalStateException("No se pudo abrir el archivo PNG");
                        output.write(ready);
                        output.flush();
                    }
                    values.clear();
                    values.put(MediaStore.Images.Media.IS_PENDING, 0);
                    activity.getContentResolver().update(uri, values, null, null);
                respond("bambamNativeSaved", requestId, true,
                        "Cartón " + number + " guardado en Galería/BAMBAM");
            } catch (Exception e) {
                if (uri != null) {
                    try { activity.getContentResolver().delete(uri, null, null); }
                    catch (Exception ignored) { }
                }
                respond("bambamNativeSaved", requestId, false, friendly(e));
            }
        });
    }

    private static void validate(int number) {
        if (number < 1 || number > 3000)
            throw new IllegalArgumentException("El cartón debe estar entre 1 y 3000");
    }

    private byte[] preparedPNG(int number) throws Exception {
        byte[] cached = readyPNG.get(number);
        if (cached != null) return cached;
        Bitmap bitmap = render(number, 2048);
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream(1700000);
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out))
                throw new IllegalStateException("No se pudo generar el PNG HD");
            byte[] data = out.toByteArray();
            readyPNG.put(number, data);
            return data;
        } finally { bitmap.recycle(); }
    }

    private byte[] thumbnail(int number) throws Exception {
        byte[] ready = thumbnails.get(number);
        if (ready != null) return ready;
        Bitmap bitmap = render(number, 1050);
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream(200000);
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out))
                throw new IllegalStateException("No se pudo preparar la vista previa");
            byte[] b = out.toByteArray();
            thumbnails.put(number, b);
            return b;
        } finally {
            bitmap.recycle();
        }
    }

    private Bitmap render(int number, int width) throws Exception {
        int block = (number - 1) / 1000;
        PdfRenderer renderer = reader(block);
        try (PdfRenderer.Page page = renderer.openPage((number - 1) % 1000)) {
            int height = (int) Math.ceil(width * (double)page.getHeight() / page.getWidth());
            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bmp.eraseColor(Color.WHITE);
            Matrix matrix = new Matrix();
            matrix.setScale(width / (float)page.getWidth(), height / (float)page.getHeight());
            page.render(bmp, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            return bmp;
        }
    }

    private PdfRenderer reader(int block) throws Exception {
        if (renderers[block] != null) return renderers[block];
        File dir = new File(activity.getCacheDir(), "bambam_catalogo");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("No se pudo preparar el catálogo");
        File output = new File(dir, "cartones_" + (block + 1) + ".pdf");
        if (!output.exists() || output.length() < 100000) {
            File temp = new File(dir, "cartones_" + (block + 1) + ".tmp");
            try (InputStream input = activity.getAssets().open("catalogo/cartones_" + (block + 1) + ".pdf");
                 FileOutputStream out = new FileOutputStream(temp)) {
                byte[] buf = new byte[65536]; int len;
                while ((len = input.read(buf)) != -1) out.write(buf, 0, len);
                out.getFD().sync();
            }
            if (!temp.renameTo(output)) throw new IllegalStateException("No se pudo preparar el catálogo PDF");
        }
        descriptors[block] = ParcelFileDescriptor.open(output, ParcelFileDescriptor.MODE_READ_ONLY);
        renderers[block] = new PdfRenderer(descriptors[block]);
        if (renderers[block].getPageCount() != 1000)
            throw new IllegalStateException("El bloque de cartones está incompleto");
        return renderers[block];
    }

    private static String friendly(Exception e) {
        return e.getMessage() == null ? "No se pudo abrir el cartón" : e.getMessage();
    }

    private void respond(String function, int requestId, boolean ok, String content) {
        if (closed) return;
        String b64 = Base64.encodeToString(content.getBytes(java.nio.charset.StandardCharsets.UTF_8),
                Base64.NO_WRAP);
        String script = "window." + function + "(" + requestId + "," + ok +
                ",decodeURIComponent(escape(atob('" + b64 + "'))))";
        activity.runOnUiThread(() -> {
            if (!closed) webView.evaluateJavascript(script, null);
        });
    }

    void close() {
        closed = true;
        io.execute(() -> {
            for (int i = 0; i < 3; i++) {
                try { if (renderers[i] != null) renderers[i].close(); }
                catch (Exception ignored) { }
                try { if (descriptors[i] != null) descriptors[i].close(); }
                catch (Exception ignored) { }
            }
        });
        io.shutdown();
    }
}
