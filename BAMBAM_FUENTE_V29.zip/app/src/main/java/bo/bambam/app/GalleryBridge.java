package bo.bambam.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.concurrent.ConcurrentHashMap;

public class GalleryBridge {
    private final MainActivity activity;
    private final WebView webView;
    private final ConcurrentHashMap<Integer, Pending> pending = new ConcurrentHashMap<>();
    private static final class Pending {
        final String filename;
        final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        Pending(String filename){this.filename=filename;}
    }
    GalleryBridge(MainActivity activity, WebView webView){this.activity=activity;this.webView=webView;}

    @JavascriptInterface public void beginPNG(String filename, int requestId){
        if(!filename.matches("BAMBAM_carton_[0-9]{1,4}\\.png")){
            respond(requestId,false,"Nombre de cartón inválido");return;
        }
        pending.put(requestId,new Pending(filename));
    }
    @JavascriptInterface public void appendPNG(int requestId, String b64chunk){
        Pending item=pending.get(requestId);
        if(item==null)return;
        try{
            byte[] part=Base64.decode(b64chunk, Base64.DEFAULT);
            synchronized(item){
                if(item.bytes.size()+part.length>24_000_000)throw new Exception("La imagen PNG es demasiado grande");
                item.bytes.write(part);
            }
        }catch(Exception e){pending.remove(requestId);respond(requestId,false,"No se pudo preparar el PNG");}
    }
    @JavascriptInterface public void finishPNG(int requestId){
        Pending item=pending.remove(requestId);
        if(item==null){respond(requestId,false,"No se recibió el PNG completo");return;}
        Uri imageUri=null;
        try {
            byte[] data=item.bytes.toByteArray();
            if(data.length<1000)throw new IllegalArgumentException("El archivo PNG está incompleto");
            if(data[0]!=(byte)0x89 || data[1]!=0x50 || data[2]!=0x4e || data[3]!=0x47)
                throw new IllegalArgumentException("No es una imagen PNG");
            ContentResolver resolver=activity.getContentResolver();
            ContentValues values=new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME,item.filename);
            values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/BAMBAM");
            values.put(MediaStore.Images.Media.IS_PENDING,1);
            imageUri=resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
            if(imageUri==null)throw new IllegalStateException("No se pudo crear la imagen en la galería");
            try(OutputStream output=resolver.openOutputStream(imageUri)){
                if(output==null)throw new IllegalStateException("No se pudo guardar el PNG");
                output.write(data);
                output.flush();
            }
            values.clear();values.put(MediaStore.Images.Media.IS_PENDING,0);
            resolver.update(imageUri,values,null,null);
            respond(requestId,true,"Imagen guardada en Galería / BAMBAM");
        }catch(Exception e){
            if(imageUri!=null){try{activity.getContentResolver().delete(imageUri,null,null);}catch(Exception ignored){}}
            respond(requestId,false,e.getMessage()==null?"No se pudo guardar la imagen":e.getMessage());
        }
    }
    private void respond(int requestId,boolean ok,String message){
        String safe=android.util.Base64.encodeToString(message.getBytes(java.nio.charset.StandardCharsets.UTF_8),Base64.NO_WRAP);
        String js="window.bambamGalleryResult("+requestId+","+ok+",decodeURIComponent(escape(atob('"+safe+"'))))";
        activity.runOnUiThread(()->webView.evaluateJavascript(js,null));
    }
}
