const CACHE='bambam-v32-instantanea';
const CORE=['./','./index.html','./manifest.webmanifest','./iconos/bambam-perfil-blanco.png','./iconos/bambam-192.png','./iconos/bambam-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('bambam-v')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{let r=e.request;if(r.method!=='GET'||new URL(r.url).origin!==self.location.origin)return;
  if(r.mode==='navigate'){e.respondWith(fetch(r).then(response=>{if(response.ok){const copy=response.clone();e.waitUntil(caches.open(CACHE).then(c=>c.put('./index.html',copy)))}return response}).catch(()=>caches.match('./index.html')))}
  else if(r.url.includes('/iconos/')){e.respondWith(caches.match(r).then(cached=>cached||fetch(r).then(resp=>{if(resp.ok){const copy=resp.clone();e.waitUntil(caches.open(CACHE).then(c=>c.put(r,copy)))}return resp})))}
});
